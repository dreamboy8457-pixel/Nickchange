# NickPlugin v2 (Paper 1.21.11)

## Build
Java 21 + Maven:  `mvn package`  ->  `target/NickPlugin-2.0.0.jar`  ->  server ke `plugins/` me daalo.

## Commands
- `/nick <name|reset|random>`         - apna nick
- `/nick <player> <name|reset|random>` - kisi aur ka nick (nickplugin.others)
- `/realname <nick>`                   - nick ke peeche ka asli naam
- `/nickadmin <list|reload|clear <player>>`

## Nick formats
`&c&lDragon`, `&#ff8800Blaze`, `<gradient:#ff0000:#0000ff>Neon</gradient>`, `<rainbow>Party</rainbow>`
(sirf unke liye jinke paas color / format / hex / gradient permission ho)

## Permissions
nickplugin.use, .others, .random, .color, .format, .hex, .gradient, .realname, .seereal, .admin,
nickplugin.bypass.cooldown, .bypass.blacklist, .bypass.impersonate

## PlaceholderAPI
%nick_name%  %nick_realname%  %nick_isnicked%

## Developer API
`NickPlugin.getInstance().getNickManager()` -> getPlain(uuid), getRealName(player), setNick(...), isNicked(player)
