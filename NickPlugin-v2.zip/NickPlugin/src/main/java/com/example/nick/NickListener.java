package com.example.nick;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class NickListener implements Listener {

    private final NickPlugin plugin;
    private final NickManager manager;
    private final Messages messages;

    public NickListener(NickPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getNickManager();
        this.messages = plugin.getMessages();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        manager.registerPlayer(p);

        if (!manager.isNicked(p)) return;

        if (plugin.getConfig().getBoolean("settings.nick-in-join-quit", true) && e.joinMessage() != null) {
            e.joinMessage(messages.noPrefix("join-message",
                    Messages.comp("nick", manager.parse(manager.getRaw(p.getUniqueId()))),
                    Messages.text("player", p.getName())));
        }

        // 1 tick baad apply, taaki join poora ho jaye
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) manager.applyVisual(p);
        });
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (manager.isNicked(p)
                && plugin.getConfig().getBoolean("settings.nick-in-join-quit", true)
                && e.quitMessage() != null) {
            e.quitMessage(messages.noPrefix("quit-message",
                    Messages.comp("nick", manager.parse(manager.getRaw(p.getUniqueId()))),
                    Messages.text("player", manager.getRealName(p))));
        }
        manager.unregisterPlayer(p);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onChat(AsyncChatEvent e) {
        if (!plugin.getConfig().getBoolean("settings.chat-hover-realname", true)) return;

        e.renderer((source, sourceDisplayName, message, viewer) -> {
            Component name = sourceDisplayName;
            if (manager.isNicked(source)
                    && viewer instanceof CommandSender cs
                    && cs.hasPermission("nickplugin.seereal")) {
                name = name.hoverEvent(HoverEvent.showText(
                        messages.noPrefix("hover-realname", Messages.text("player", manager.getRealName(source)))));
            }
            return Component.translatable("chat.type.text", name, message);
        });
    }
}
