package com.example.nick;

import org.bukkit.plugin.java.JavaPlugin;

public class NickPlugin extends JavaPlugin {

    private static NickPlugin instance;
    private Messages messages;
    private NickManager manager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        messages = new Messages(this);
        manager = new NickManager(this);
        manager.load();

        getServer().getPluginManager().registerEvents(new NickListener(this), this);

        NickCommand nick = new NickCommand(this);
        getCommand("nick").setExecutor(nick);
        getCommand("nick").setTabCompleter(nick);

        RealNameCommand real = new RealNameCommand(this);
        getCommand("realname").setExecutor(real);
        getCommand("realname").setTabCompleter(real);

        NickAdminCommand admin = new NickAdminCommand(this);
        getCommand("nickadmin").setExecutor(admin);
        getCommand("nickadmin").setTabCompleter(admin);

        // PlaceholderAPI (optional)
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new NickPlaceholders(this).register();
            getLogger().info("PlaceholderAPI hooked: %nick_name%, %nick_realname%, %nick_isnicked%");
        }

        getLogger().info("NickPlugin enabled!");
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.shutdown();
    }

    public void reloadAll() {
        reloadConfig();
    }

    public Messages getMessages() { return messages; }

    /** Public API: doosre plugins yahan se NickManager use kar sakte hain. */
    public NickManager getNickManager() { return manager; }

    public static NickPlugin getInstance() { return instance; }
}
