package com.example.nick;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/**
 * %nick_name%      -> nick (plain), nick na ho toh asli naam
 * %nick_realname%  -> asli Minecraft naam
 * %nick_isnicked%  -> true / false
 */
public class NickPlaceholders extends PlaceholderExpansion {

    private final NickPlugin plugin;

    public NickPlaceholders(NickPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "nick";
    }

    @Override
    public @NotNull String getAuthor() {
        return "YourName";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        NickManager m = plugin.getNickManager();
        String real = m.getRealName(player.getUniqueId(), player.getName() == null ? "" : player.getName());
        String nick = m.getPlain(player.getUniqueId());

        return switch (params.toLowerCase()) {
            case "name" -> nick != null ? nick : real;
            case "realname" -> real;
            case "isnicked" -> String.valueOf(nick != null);
            default -> null;
        };
    }
}
