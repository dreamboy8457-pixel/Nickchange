package com.example.nick;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class NickCommand implements TabExecutor {

    private final NickManager manager;
    private final Messages msg;

    public NickCommand(NickPlugin plugin) {
        this.manager = plugin.getNickManager();
        this.msg = plugin.getMessages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length < 1 || args.length > 2) {
            msg.send(sender, "usage");
            return true;
        }

        Player target;
        String input;

        if (args.length == 1) {
            if (!(sender instanceof Player p)) {
                msg.send(sender, "console-needs-player");
                return true;
            }
            if (!sender.hasPermission("nickplugin.use")) {
                msg.send(sender, "no-permission");
                return true;
            }
            target = p;
            input = args[0];
        } else {
            if (!sender.hasPermission("nickplugin.others")) {
                msg.send(sender, "no-permission");
                return true;
            }
            target = manager.findPlayer(args[0]);
            if (target == null) {
                msg.send(sender, "player-not-found", Messages.text("player", args[0]));
                return true;
            }
            input = args[1];
        }

        boolean isSelf = target.equals(sender);

        // ---- RESET ----
        if (input.equalsIgnoreCase("reset")) {
            if (!manager.isNicked(target)) {
                msg.send(sender, "not-nicked");
                return true;
            }
            String real = manager.getRealName(target);
            manager.resetNick(target);
            msg.send(target, "nick-reset-self");
            if (!isSelf) msg.send(sender, "nick-reset-other", Messages.text("player", real));
            return true;
        }

        // ---- COOLDOWN (sirf self-use) ----
        if (isSelf && !sender.hasPermission("nickplugin.bypass.cooldown")) {
            long left = manager.cooldownLeft(target.getUniqueId());
            if (left > 0) {
                msg.send(sender, "cooldown", Messages.text("seconds", String.valueOf(left)));
                return true;
            }
        }

        // ---- RANDOM ----
        String cleaned;
        if (input.equalsIgnoreCase("random")) {
            if (!sender.hasPermission("nickplugin.random")) {
                msg.send(sender, "no-permission");
                return true;
            }
            cleaned = manager.randomName(target);
            if (cleaned == null) {
                msg.send(sender, "no-random");
                return true;
            }
        } else {
            cleaned = manager.sanitize(sender, input);
            NickManager.Error err = manager.validate(sender, target, cleaned);
            if (err != null) {
                msg.send(sender, err.key(), err.resolvers());
                return true;
            }
        }

        // ---- APPLY ----
        String real = manager.getRealName(target);
        manager.setNick(target, cleaned);
        if (isSelf) manager.markCooldown(target.getUniqueId());

        Component nick = manager.getDisplay(target);
        if (isSelf) {
            msg.send(target, "nick-set-self", Messages.comp("nick", nick));
        } else {
            msg.send(sender, "nick-set-other", Messages.text("player", real), Messages.comp("nick", nick));
            msg.send(target, "nick-changed-by-admin", Messages.comp("nick", nick));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            addIfMatch(out, "reset", args[0]);
            if (sender.hasPermission("nickplugin.random")) addIfMatch(out, "random", args[0]);
            if (sender.hasPermission("nickplugin.others")) {
                for (Player p : Bukkit.getOnlinePlayers()) addIfMatch(out, manager.getRealName(p), args[0]);
            }
        } else if (args.length == 2 && sender.hasPermission("nickplugin.others")) {
            addIfMatch(out, "reset", args[1]);
            if (sender.hasPermission("nickplugin.random")) addIfMatch(out, "random", args[1]);
        }
        return out;
    }

    private void addIfMatch(List<String> list, String option, String typed) {
        if (option.toLowerCase().startsWith(typed.toLowerCase())) list.add(option);
    }
}
