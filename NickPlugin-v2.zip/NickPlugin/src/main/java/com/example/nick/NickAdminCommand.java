package com.example.nick;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class NickAdminCommand implements TabExecutor {

    private final NickPlugin plugin;
    private final NickManager manager;
    private final Messages msg;

    public NickAdminCommand(NickPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getNickManager();
        this.msg = plugin.getMessages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("nickplugin.admin")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            msg.send(sender, "admin-usage");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadAll();
                msg.send(sender, "admin-reload");
            }
            case "list" -> {
                Map<UUID, String> all = manager.getAllNicks();
                if (all.isEmpty()) {
                    msg.send(sender, "admin-list-empty");
                    return true;
                }
                msg.send(sender, "admin-list-header", Messages.text("count", String.valueOf(all.size())));
                int shown = 0;
                for (Map.Entry<UUID, String> e : all.entrySet()) {
                    if (shown++ >= 50) break;
                    OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
                    String name = op.getName() != null ? op.getName() : e.getKey().toString();
                    msg.send(sender, "admin-list-entry",
                            Messages.text("player", name),
                            Messages.comp("nick", manager.parse(e.getValue())));
                }
            }
            case "clear" -> {
                if (args.length < 2) {
                    msg.send(sender, "admin-usage");
                    return true;
                }
                Player target = manager.findPlayer(args[1]);
                if (target == null) {
                    msg.send(sender, "player-not-found", Messages.text("player", args[1]));
                    return true;
                }
                if (!manager.isNicked(target)) {
                    msg.send(sender, "not-nicked");
                    return true;
                }
                String real = manager.getRealName(target);
                manager.resetNick(target);
                msg.send(target, "nick-reset-self");
                msg.send(sender, "admin-cleared", Messages.text("player", real));
            }
            default -> msg.send(sender, "admin-usage");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("nickplugin.admin")) return out;
        if (args.length == 1) {
            for (String s : List.of("list", "reload", "clear")) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("clear")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (manager.isNicked(p) && manager.getRealName(p).toLowerCase().startsWith(args[1].toLowerCase())) {
                    out.add(manager.getRealName(p));
                }
            }
        }
        return out;
    }
}
