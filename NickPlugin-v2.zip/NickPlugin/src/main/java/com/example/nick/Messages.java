package com.example.nick;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;

public class Messages {

    private final NickPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public Messages(NickPlugin plugin) {
        this.plugin = plugin;
    }

    private String raw(String key) {
        return plugin.getConfig().getString("messages." + key, "<red>Missing message: " + key);
    }

    /** Prefix ke saath message. */
    public Component get(String key, TagResolver... resolvers) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        return mm.deserialize(prefix + raw(key), resolvers);
    }

    /** Bina prefix ke message. */
    public Component noPrefix(String key, TagResolver... resolvers) {
        return mm.deserialize(raw(key), resolvers);
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(get(key, resolvers));
    }

    public static TagResolver text(String key, String value) {
        return Placeholder.unparsed(key, value);
    }

    public static TagResolver comp(String key, Component value) {
        return Placeholder.component(key, value);
    }
}
