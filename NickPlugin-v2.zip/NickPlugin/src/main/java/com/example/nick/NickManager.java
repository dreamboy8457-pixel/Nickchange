package com.example.nick;

import com.destroystokyo.paper.profile.PlayerProfile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.minimessage.tag.standard.StandardTags;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class NickManager {

    public record Error(String key, TagResolver[] resolvers) {}

    private static final Pattern HEX = Pattern.compile("&#[0-9a-fA-F]{6}");
    private static final Pattern COLOR = Pattern.compile("&[0-9a-fA-F]");
    private static final Pattern FORMAT = Pattern.compile("&[k-oK-OrR]");
    private static final Pattern TAGS = Pattern.compile("<[^<>]*>");
    private static final Pattern VALID = Pattern.compile("^[A-Za-z0-9_]+$");
    private static final Map<Character, String> LEGACY = new HashMap<>();

    static {
        String codes = "0123456789abcdefklmnor";
        String[] tags = {
                "black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray",
                "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white",
                "obfuscated", "bold", "strikethrough", "underlined", "italic", "reset"
        };
        for (int i = 0; i < codes.length(); i++) {
            LEGACY.put(codes.charAt(i), "<" + tags[i] + ">");
        }
    }

    // Sirf safe tags allowed (click/hover/insert jaise tags blocked)
    private final MiniMessage nickMM = MiniMessage.builder()
            .tags(TagResolver.resolver(
                    StandardTags.color(),
                    StandardTags.decorations(),
                    StandardTags.gradient(),
                    StandardTags.rainbow(),
                    StandardTags.reset()))
            .build();

    private final NickPlugin plugin;
    private final File dataFile;

    private final Map<UUID, String> nicks = new ConcurrentHashMap<>();
    private final Map<UUID, PlayerProfile> originalProfiles = new ConcurrentHashMap<>();
    private final Map<UUID, String> originalNames = new ConcurrentHashMap<>();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    public NickManager(NickPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ================= Load / Save =================

    public void load() {
        nicks.clear();
        if (dataFile.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
            ConfigurationSection s = y.getConfigurationSection("nicks");
            if (s != null) {
                for (String key : s.getKeys(false)) {
                    try {
                        String val = s.getString(key);
                        if (val != null) nicks.put(UUID.fromString(key), val);
                    } catch (IllegalArgumentException ignored) {
                    }
                }
            }
        }
        // Already online players (late load)
        for (Player p : Bukkit.getOnlinePlayers()) {
            registerPlayer(p);
            if (nicks.containsKey(p.getUniqueId())) applyVisual(p);
        }
    }

    private void saveAsync() {
        Map<UUID, String> snapshot = new HashMap<>(nicks);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> writeData(snapshot));
    }

    private synchronized void writeData(Map<UUID, String> snapshot) {
        YamlConfiguration y = new YamlConfiguration();
        snapshot.forEach((id, nick) -> y.set("nicks." + id, nick));
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("data.yml save nahi hui: " + e.getMessage());
        }
    }

    public void shutdown() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerProfile orig = originalProfiles.get(p.getUniqueId());
            if (orig != null && nicks.containsKey(p.getUniqueId())) {
                p.setPlayerProfile(orig);
                p.displayName(null);
                p.playerListName(null);
            }
            removeTeam(p);
        }
        writeData(new HashMap<>(nicks));
    }

    // ================= Player tracking =================

    public void registerPlayer(Player p) {
        originalProfiles.put(p.getUniqueId(), p.getPlayerProfile());
        originalNames.put(p.getUniqueId(), p.getName());
    }

    public void unregisterPlayer(Player p) {
        removeTeam(p);
        originalProfiles.remove(p.getUniqueId());
        originalNames.remove(p.getUniqueId());
    }

    // ================= Getters / API =================

    public boolean isNicked(Player p) {
        return nicks.containsKey(p.getUniqueId());
    }

    public String getRaw(UUID id) {
        return nicks.get(id);
    }

    public Map<UUID, String> getAllNicks() {
        return Collections.unmodifiableMap(nicks);
    }

    /** Colored nick component (ya nick na ho toh normal displayName). */
    public Component getDisplay(Player p) {
        String raw = nicks.get(p.getUniqueId());
        return raw == null ? p.displayName() : parse(raw);
    }

    /** Plain (bina color) nick. Nick na ho toh null. */
    public String getPlain(UUID id) {
        String raw = nicks.get(id);
        return raw == null ? null : plainOf(raw);
    }

    public String getRealName(Player p) {
        return originalNames.getOrDefault(p.getUniqueId(), p.getName());
    }

    public String getRealName(UUID id, String fallback) {
        return originalNames.getOrDefault(id, fallback);
    }

    public Player findPlayer(String input) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (getRealName(p).equalsIgnoreCase(input) || p.getName().equalsIgnoreCase(input)) return p;
        }
        return null;
    }

    // ================= Parsing / Validation =================

    private String toMiniMessage(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '&' && i + 1 < s.length()) {
                char n = s.charAt(i + 1);
                if (n == '#' && i + 8 <= s.length()) {
                    String hex = s.substring(i + 2, i + 8);
                    if (hex.matches("[0-9a-fA-F]{6}")) {
                        sb.append("<#").append(hex).append(">");
                        i += 7;
                        continue;
                    }
                }
                String tag = LEGACY.get(Character.toLowerCase(n));
                if (tag != null) {
                    sb.append(tag);
                    i++;
                    continue;
                }
            }
            sb.append(c);
        }
        return sb.toString();
    }

    public Component parse(String raw) {
        return nickMM.deserialize(toMiniMessage(raw));
    }

    public String plainOf(String raw) {
        return PlainTextComponentSerializer.plainText().serialize(parse(raw));
    }

    /** Sender ki permissions ke hisaab se colors/format/tags hata deta hai. */
    public String sanitize(CommandSender s, String in) {
        String r = in;
        if (!s.hasPermission("nickplugin.hex")) r = HEX.matcher(r).replaceAll("");
        if (!s.hasPermission("nickplugin.color")) r = COLOR.matcher(r).replaceAll("");
        if (!s.hasPermission("nickplugin.format")) r = FORMAT.matcher(r).replaceAll("");
        if (!s.hasPermission("nickplugin.gradient")) r = TAGS.matcher(r).replaceAll("");
        return r;
    }

    public Error validate(CommandSender actor, Player target, String cleaned) {
        String plain = plainOf(cleaned);
        int min = cfg().getInt("settings.min-length", 3);
        int max = Math.min(16, cfg().getInt("settings.max-length", 16));

        if (plain.length() < min || plain.length() > max) {
            return new Error("invalid-length", new TagResolver[]{
                    Messages.text("min", String.valueOf(min)), Messages.text("max", String.valueOf(max))});
        }
        if (!VALID.matcher(plain).matches()) {
            return new Error("invalid-chars", new TagResolver[0]);
        }
        if (!actor.hasPermission("nickplugin.bypass.blacklist")) {
            String low = plain.toLowerCase();
            for (String word : cfg().getStringList("settings.blacklist")) {
                if (!word.isBlank() && low.contains(word.toLowerCase())) {
                    return new Error("blacklisted", new TagResolver[]{Messages.text("word", word)});
                }
            }
        }
        if (isTaken(plain, target.getUniqueId())) {
            return new Error("name-taken", new TagResolver[0]);
        }
        if (!actor.hasPermission("nickplugin.bypass.impersonate")) {
            OfflinePlayer known = Bukkit.getOfflinePlayerIfCached(plain);
            if (known != null && !known.getUniqueId().equals(target.getUniqueId())) {
                return new Error("impersonation", new TagResolver[0]);
            }
        }
        return null;
    }

    private boolean isTaken(String plain, UUID except) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getUniqueId().equals(except)) continue;
            if (getRealName(p).equalsIgnoreCase(plain)) return true;
        }
        for (Map.Entry<UUID, String> e : nicks.entrySet()) {
            if (e.getKey().equals(except)) continue;
            if (plainOf(e.getValue()).equalsIgnoreCase(plain)) return true;
        }
        return false;
    }

    public String randomName(Player target) {
        List<String> list = new ArrayList<>(cfg().getStringList("settings.random-names"));
        Collections.shuffle(list);
        for (String name : list) {
            if (validate(target, target, name) == null) return name;
        }
        return null;
    }

    // ================= Cooldown =================

    public long cooldownLeft(UUID id) {
        long end = cooldowns.getOrDefault(id, 0L);
        long left = (end - System.currentTimeMillis() + 999) / 1000;
        return Math.max(0, left);
    }

    public void markCooldown(UUID id) {
        int secs = cfg().getInt("settings.cooldown-seconds", 30);
        if (secs > 0) cooldowns.put(id, System.currentTimeMillis() + secs * 1000L);
    }

    // ================= Apply / Reset =================

    public void setNick(Player p, String cleanedRaw) {
        nicks.put(p.getUniqueId(), cleanedRaw);
        applyVisual(p);
        saveAsync();

        Component nick = parse(cleanedRaw);
        playEffects(p);
        if (cfg().getBoolean("settings.effects.enabled", true) && cfg().getBoolean("settings.effects.title", true)) {
            p.showTitle(Title.title(
                    plugin.getMessages().noPrefix("title-main", Messages.comp("nick", nick)),
                    plugin.getMessages().noPrefix("title-sub", Messages.comp("nick", nick))));
        }
        if (cfg().getBoolean("settings.broadcast-changes", false)) {
            Bukkit.broadcast(plugin.getMessages().get("broadcast",
                    Messages.text("player", getRealName(p)), Messages.comp("nick", nick)));
        }
    }

    public void resetNick(Player p) {
        PlayerProfile orig = originalProfiles.get(p.getUniqueId());
        if (orig != null) p.setPlayerProfile(orig);
        p.displayName(null);
        p.playerListName(null);
        removeTeam(p);
        nicks.remove(p.getUniqueId());
        saveAsync();
        playEffects(p);
    }

    /** Profile name (nametag + tab) + displayName (chat) + team color set karta hai. */
    public void applyVisual(Player p) {
        UUID id = p.getUniqueId();
        String raw = nicks.get(id);
        PlayerProfile orig = originalProfiles.get(id);
        if (raw == null || orig == null) return;

        Component comp = parse(raw);
        String plain = plainOf(raw);

        PlayerProfile np = Bukkit.createProfile(id, plain); // same UUID + same skin
        np.setProperties(orig.getProperties());
        p.setPlayerProfile(np);

        p.displayName(comp);
        p.playerListName(comp);
        applyTeam(p, plain, comp);
    }

    // ================= Nametag color (scoreboard team) =================

    private Scoreboard board() {
        return Bukkit.getScoreboardManager().getMainScoreboard();
    }

    private String teamName(Player p) {
        return "nk_" + p.getUniqueId().toString().replace("-", "").substring(0, 13);
    }

    private TextColor firstColor(Component c) {
        if (c.color() != null) return c.color();
        for (Component child : c.children()) {
            TextColor col = firstColor(child);
            if (col != null) return col;
        }
        return null;
    }

    private void applyTeam(Player p, String plainNick, Component comp) {
        removeTeam(p);
        if (!cfg().getBoolean("settings.nametag-color", true)) return;

        TextColor col = firstColor(comp);
        if (col == null) return;

        Scoreboard b = board();
        Team existing = b.getEntryTeam(plainNick);
        if (existing != null) return; // kisi aur plugin ki team hai, chhedna nahi

        Team t = b.registerNewTeam(teamName(p));
        t.color(NamedTextColor.nearestTo(col));
        t.addEntry(plainNick);
    }

    private void removeTeam(Player p) {
        Team t = board().getTeam(teamName(p));
        if (t != null) t.unregister();
    }

    // ================= Effects =================

    private void playEffects(Player p) {
        if (!cfg().getBoolean("settings.effects.enabled", true)) return;
        if (cfg().getBoolean("settings.effects.particles", true)) {
            p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0),
                    40, 0.4, 0.6, 0.4, 0.2);
        }
        if (cfg().getBoolean("settings.effects.sound", true)) {
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        }
    }
}
