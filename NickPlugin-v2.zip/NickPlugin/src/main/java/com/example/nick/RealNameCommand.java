package com.example.nick;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class RealNameCommand implements TabExecutor {

    private final NickManager manager;
    private final Messages msg;

    public RealNameCommand(NickPlugin plugin) {
        this.manager = plugin.getNickManager();
        this.msg = plugin.getMessages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("nickplugin.realname")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length != 1) {
            msg.send(sender, "realname-usage");
            return true;
        }

        String q = args[0].toLowerCase();
        boolean found = false;
        for (Player p : Bukkit.getOnlinePlayers()) {
            String plain = manager.getPlain(p.getUniqueId());
            if (plain != null && plain.toLowerCase().contains(q)) {
                found = true;
                msg.send(sender, "realname-result",
                        Messages.comp("nick", manager.getDisplay(p)),
                        Messages.text("player", manager.getRealName(p)));
            }
        }
        if (!found) msg.send(sender, "realname-none");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                String plain = manager.getPlain(p.getUniqueId());
                if (plain != null && plain.toLowerCase().startsWith(args[0].toLowerCase())) out.add(plain);
            }
        }
        return out;
    }
}
